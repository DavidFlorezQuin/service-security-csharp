﻿using Data.Dto;
using Entity.Model.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Implementation
{
    public interface IModuleData
    {
        Task Delete(int id);
        Task<IEnumerable<DataSelectDto>> GetAllSelect();
        Task<Module> Save(Module entity);
        Task Update(Module entity);
        Task<Module> GetById(int id);
        Task<PagedListDto<ModuloDto>> GetDataTable(QueryFilterDto filter);
    }
}
