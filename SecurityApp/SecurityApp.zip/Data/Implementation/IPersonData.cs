﻿using Data.Dto;
using Entity.Model.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Implementation
{
    public interface IPersonData
    {
        Task Delete(int id);
        Task<IEnumerable<DataSelectDto>> GetAllSelect();
        Task<Person> Save(Person entity);
        Task Update(Person entity);

        Task<Person> GetById(int id);

        Task<PagedListDto<PersonDto>> GetDataTable(QueryFilterDto filter);
    }
}
