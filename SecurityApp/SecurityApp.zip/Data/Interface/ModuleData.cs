﻿using Data.Dto;
using Data.Implementation;
using Entity.Model.Context;
using Entity.Model.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Interface
{
    public class ModuleData : IModuleData
    {


        private readonly AplicationDbContext context;
        protected readonly IConfiguration configuration;

        public ModuleData(AplicationDbContext context, IConfiguration configuration)
        {
            this.context = context;
            this.configuration = configuration;
        }


        public async Task Delete(int id)
        {
            var entity = await GetById(id);
            if (entity == null)
            {
                throw new Exception("Registro no encontrado");
            }
            entity.deleted_at = DateTime.Parse(DateTime.Today.ToString());
            context.modules.Update(entity);
            await context.SaveChangesAsync();
        }
        public async Task<IEnumerable<DataSelectDto>> GetAllSelect()
        {
            var sql = @"SELECT 
                        Id,
                        name AS Nombre 
                    FROM 
                        Parametro.Module
                    WHERE DeletedAt IS NULL AND Estado = 1
                    ORDER BY Id ASC";
            return await context.QueryAsync<DataSelectDto>(sql);
        }

        public async Task<Module> GetById(int id)
        {
            var sql = @"SELECT * FROM Parametro.Module WHERE Id = @Id ORDER BY Id ASC";
            return await context.QueryFirstOrDefaultAsync<Module>(sql, new { Id = id });
        }


        public async Task<PagedListDto<ModuloDto>> GetDataTable(QueryFilterDto filter)
        {
            int pageNumber = filter.PageNumber == 0 ? int.Parse(configuration["Pagination:DefaultPageNumber"]) : filter.PageNumber;
            int pageSize = filter.PageSize == 0 ? int.Parse(configuration["Pagination:DefaultPageSize"]) : filter.PageSize;

            var sql = @"SELECT
                m.Id,
                m.name AS Name,
                m.description AS Description
            FROM Parametro.Module r
            WHERE
            r.deleted_at IS NULL AND
                (UPPER(CONCAT(p.first_name, p.last_name)) LIKE UPPER(CONCAT('%', @filter, '%')))
            ORDER BY " + (filter.ColumnOrder ?? "p.Id") + " " + (filter.DirectionOrder ?? "asc");

            IEnumerable<ModuloDto> items = await context.QueryAsync<ModuloDto>(sql, new { filter.Filter });

            var pagedItems = PagedListDto<ModuloDto>.Create(items, pageNumber, pageSize);

            return pagedItems;
        }


        public async Task<Module> Save(Module entity)
        {
            context.modules.Add(entity);
            await context.SaveChangesAsync();
            return entity;
        }

        public async Task Update(Module entity)
        {
            context.Entry(entity).State = EntityState.Modified;
            await context.SaveChangesAsync();
        }
    }
}
